*******************
``matplotlib.text``
*******************

.. redirect-from:: /api/textpath_api

.. automodule:: matplotlib.text
   :no-members:

.. autoclass:: matplotlib.text.Text
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: matplotlib.text.Annotation
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: matplotlib.text.OffsetFrom
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: matplotlib.text.TextPath
   :members:
   :undoc-members:
   :show-inheritance:

.. autoclass:: matplotlib.text.TextToPath
   :members:
   :undoc-members:
   :show-inheritance:
