==============================
``matplotlib.sphinxext.roles``
==============================

.. automodule:: matplotlib.sphinxext.roles
   :no-undoc-members:
   :private-members: _rcparam_role, _mpltype_role
