<!--placeholder page so Github knows we have a CoC-->

Our Code of Conduct is at
https://matplotlib.org/stable/project/code_of_conduct.html

It is rendered from `doc/project/code_of_conduct.rst`
