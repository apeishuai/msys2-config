*********
``pylab``
*********

.. automodule:: pylab
   :no-members:
