***********************************
``matplotlib.backends.backend_agg``
***********************************

.. automodule:: matplotlib.backends.backend_agg
   :members:
   :undoc-members:
   :show-inheritance:
