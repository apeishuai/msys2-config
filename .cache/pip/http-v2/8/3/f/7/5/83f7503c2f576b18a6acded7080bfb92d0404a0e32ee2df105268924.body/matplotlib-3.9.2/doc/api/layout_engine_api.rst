****************************
``matplotlib.layout_engine``
****************************

.. currentmodule:: matplotlib.layout_engine

.. automodule:: matplotlib.layout_engine
   :members:
   :inherited-members:
