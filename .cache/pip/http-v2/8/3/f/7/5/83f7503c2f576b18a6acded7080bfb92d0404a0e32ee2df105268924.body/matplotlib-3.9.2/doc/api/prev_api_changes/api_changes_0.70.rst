Changes for 0.70
================

.. code-block:: text

   MplEvent factored into a base class Event and derived classes
   MouseEvent and KeyEvent

   Removed defunct set_measurement in wx toolbar
